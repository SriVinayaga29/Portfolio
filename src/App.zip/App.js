import React from "react";
import NavBar from "./Portfolio/Navbar";
import Home from "./Portfolio/Home/Home";
import About from "./Portfolio/About/About"; 
import Skills from "./Portfolio/Skills/Skills";
import Works from "./Portfolio/Works/works";
import Contact from "./Portfolio/Contact/Contact";



function App() {
    return (
        <>
            <NavBar />
            <section id="Home"><Home /></section>
            <section id="About"><About /></section>
            <section id="Skills"><Skills /></section>
            <section id="Works"><Works /></section>
            <section id="Contact"><Contact /></section>
        </>
    );
}

export default App;
